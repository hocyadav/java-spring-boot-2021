package io.hari.demo.dao;

import io.hari.demo.entity.Entity2;
import org.springframework.stereotype.Repository;

@Repository
public interface Entity2Dao extends BaseDao<Entity2>{
}
