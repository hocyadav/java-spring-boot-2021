package io.hari.demo.constant;

public class AppConstant {
    public final static String CONSTANT_1 = "constant1";
    public final static String ERROR_MESSAGE = "error";
    public final static String SUCCESS_MESSAGE = "error";
}
